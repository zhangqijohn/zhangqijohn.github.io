'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://www.dev.q1op.com/"'
}
