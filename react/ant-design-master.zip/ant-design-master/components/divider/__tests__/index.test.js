import Divider from '..';
import mountTest from '../../../tests/shared/mountTest';

describe('Divider', () => {
  mountTest(Divider);
});
