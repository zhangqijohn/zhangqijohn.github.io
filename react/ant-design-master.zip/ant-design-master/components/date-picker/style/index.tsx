import '../../style/index.less';
import './index.less';

// style dependencies
// deps-lint-skip: input
import '../../input/style';
import '../../time-picker/style';
import '../../tag/style';
