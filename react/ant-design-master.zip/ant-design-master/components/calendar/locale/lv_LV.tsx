import lv_LV from '../../date-picker/locale/lv_LV';

export default lv_LV;
