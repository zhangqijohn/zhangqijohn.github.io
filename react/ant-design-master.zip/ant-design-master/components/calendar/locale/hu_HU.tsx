import hu_HU from '../../date-picker/locale/hu_HU';

export default hu_HU;
