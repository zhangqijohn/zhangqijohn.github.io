import nl_BE from '../../date-picker/locale/nl_BE';

export default nl_BE;
