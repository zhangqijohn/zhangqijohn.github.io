import da_DK from '../../date-picker/locale/da_DK';

export default da_DK;
