import vi_VN from '../../date-picker/locale/vi_VN';

export default vi_VN;
