import sk_SK from '../../date-picker/locale/sk_SK';

export default sk_SK;
