import ja_JP from '../../date-picker/locale/ja_JP';

export default ja_JP;
