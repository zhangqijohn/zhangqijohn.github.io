import id_ID from '../../date-picker/locale/id_ID';

export default id_ID;
