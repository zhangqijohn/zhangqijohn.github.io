import hr_HR from '../../date-picker/locale/hr_HR';

export default hr_HR;
