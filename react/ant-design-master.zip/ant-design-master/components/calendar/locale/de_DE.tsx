import de_DE from '../../date-picker/locale/de_DE';

export default de_DE;
