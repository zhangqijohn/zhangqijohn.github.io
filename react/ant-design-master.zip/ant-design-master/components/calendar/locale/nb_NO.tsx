import nb_NO from '../../date-picker/locale/nb_NO';

export default nb_NO;
