import sr_RS from '../../date-picker/locale/sr_RS';

export default sr_RS;
