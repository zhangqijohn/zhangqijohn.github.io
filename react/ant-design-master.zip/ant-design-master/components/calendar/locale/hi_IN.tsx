import hi_IN from '../../date-picker/locale/hi_IN';

export default hi_IN;
