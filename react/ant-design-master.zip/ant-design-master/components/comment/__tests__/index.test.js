import Comment from '../index';
import mountTest from '../../../tests/shared/mountTest';

describe('Comment', () => {
  mountTest(Comment);
});
