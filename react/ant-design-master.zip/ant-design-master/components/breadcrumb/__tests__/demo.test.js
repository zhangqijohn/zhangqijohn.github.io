import demoTest from '../../../tests/shared/demoTest';

demoTest('breadcrumb', { skip: ['router.md', 'router-4.md'] });
