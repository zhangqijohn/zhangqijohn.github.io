// deps-lint-skip: empty
import '../../style/index.less';
import './index.less';
