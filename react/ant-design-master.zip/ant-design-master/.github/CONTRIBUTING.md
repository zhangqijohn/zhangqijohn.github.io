# Contributing to Ant Design

Want to contribute to Ant Design? There are a few things you need to know.

We wrote a **[contribution guide](https://ant.design/docs/react/contributing)** to help you get started.

---

# 参与共建

想要给 Ant Design 贡献自己的一份力量？

我们写了一份 **[贡献指南](https://ant.design/docs/react/contributing-cn)** 来帮助你开始。
